
export const initDB = async():Promise<any>=>{
  /* this function intialise the database a each launching of the application */
  try {
 

  } catch (error) {
    throw new Error('Error when initialising the database '+error)
  }
}